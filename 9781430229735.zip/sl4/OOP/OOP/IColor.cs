﻿using System;
namespace OOP
{
    interface IColor
    {
        void SetMyColor();
    }
}
