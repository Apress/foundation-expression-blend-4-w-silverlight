﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace OOP
{
    public abstract class Fruit : OOP.IColor
    {
        private bool _IsEdible = true;
        public bool IsEdible
        {
            get { return _IsEdible; }
        }

        private FruitColor _MyFruitColor = FruitColor.None;
        public FruitColor MyFruitColor
        {
            get { return _MyFruitColor; }
            set { _MyFruitColor = value; }
        }

        public enum FruitColor
        {
            None,
            Green,
            Red,
            Yellow
        }


        public abstract void SetMyColor();
    }
}
