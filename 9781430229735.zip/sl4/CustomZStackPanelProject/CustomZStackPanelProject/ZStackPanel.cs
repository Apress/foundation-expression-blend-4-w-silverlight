﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace CustomZStackPanelProject
{
    public class ZStackPanel : Panel
    {
        private Random rnd = new Random();

        #region MaxRotation (DependencyProperty)

        public double MaxRotation
        {
            get { return (double)GetValue(MaxRotationProperty); }
            set { SetValue(MaxRotationProperty, value); }
        }
        public static readonly DependencyProperty MaxRotationProperty = DependencyProperty.Register("MaxRotation", typeof(double),
            typeof(ZStackPanel),
            new PropertyMetadata(0.0, new PropertyChangedCallback(OnMaxRotationChanged)));

        private static void OnMaxRotationChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            ((ZStackPanel)d).OnMaxRotationChanged(e);
        }

        protected virtual void OnMaxRotationChanged(DependencyPropertyChangedEventArgs e)
        {
        }

        #endregion MaxRotation (DependencyProperty)


        #region MaxOffset (DependencyProperty)

        public double MaxOffset
        {
            get { return (double)GetValue(MaxOffsetProperty); }
            set { SetValue(MaxOffsetProperty, value); }
        }
        public static readonly DependencyProperty MaxOffsetProperty = DependencyProperty.Register("MaxOffset", typeof(double),
            typeof(ZStackPanel),
            new PropertyMetadata(0.0, new PropertyChangedCallback(OnMaxOffsetChanged)));

        private static void OnMaxOffsetChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            ((ZStackPanel)d).OnMaxOffsetChanged(e);
        }

        protected virtual void OnMaxOffsetChanged(DependencyPropertyChangedEventArgs e)
        {
        }

        #endregion MaxOffset (DependencyProperty)

        public ZStackPanel()
            : base()
        {

        }


        protected override Size MeasureOverride(Size availableSize)
        {
            Size resultSize = new Size(0, 0);
            foreach (UIElement child in Children)
            {
                child.Measure(availableSize);
                resultSize.Width = Math.Max(resultSize.Width,
        child.DesiredSize.Width);
                resultSize.Height = Math.Max(resultSize.Height,
        child.DesiredSize.Height);
            }

            resultSize.Width = double.IsPositiveInfinity(availableSize.Width) ?
         resultSize.Width : availableSize.Width;
            resultSize.Height = double.IsPositiveInfinity(availableSize.Height)
         ? resultSize.Height : availableSize.Height;

            return resultSize;

        }

        protected override Size ArrangeOverride(Size finalSize)
        {
            foreach (UIElement child in Children)
            {
                double childX = finalSize.Width / 2 - child.DesiredSize.Width
         / 2;
                double childY = finalSize.Height / 2 - child.DesiredSize.Height
         / 2;
                child.Arrange(new Rect(childX, childY,
        child.DesiredSize.Width, child.DesiredSize.Height));

                RotateAndOffsetChild(child);
            }
            return finalSize;

        }

        private void RotateAndOffsetChild(UIElement child)
        {
            double xOffset = MaxOffset * (2 * rnd.NextDouble() - 1);
            double yOffset = MaxOffset * (2 * rnd.NextDouble() - 1);
            double angle = MaxRotation * (2 * rnd.NextDouble() - 1);

            TranslateTransform offsetTF = new TranslateTransform();
            offsetTF.X = xOffset;
            offsetTF.Y = yOffset;

            RotateTransform rotateRT = new RotateTransform();
            rotateRT.Angle = angle;
            rotateRT.CenterX = child.DesiredSize.Width / 2;
            rotateRT.CenterY = child.DesiredSize.Height / 2;

            TransformGroup tfg = new TransformGroup();
            tfg.Children.Add(offsetTF);
            tfg.Children.Add(rotateRT);
            child.RenderTransform = tfg;

        }


    }
}



