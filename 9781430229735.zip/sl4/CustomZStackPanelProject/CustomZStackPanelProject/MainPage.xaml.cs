﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace CustomZStackPanelProject
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
            ImageSelector.MouseLeftButtonDown += new MouseButtonEventHandler(ImageSelector_MouseLeftButtonDown);
        }

        void ImageSelector_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // create a generic object and make it equal to the very first item 
            // in ZStackLB ListBox.
            object o = ZStackLB.Items.ElementAt(ZStackLB.Items.Count - 1);
            // Make certain the o actually exists and is not null
            if (o != null)
            {
                // Remove o (the first image in the ZStackLB ListBox
                ZStackLB.Items.RemoveAt(ZStackLB.Items.Count - 1);
                // Add o back to the ZStackLB ListBox at the 0 position 
                //(the last item in the ListBox)
                ZStackLB.Items.Insert(0, o);
            }

        }
    }
}
