﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace DefaultOutOfBrowserProject
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
            App.Current.CheckAndDownloadUpdateAsync();
            App.Current.CheckAndDownloadUpdateCompleted += new CheckAndDownloadUpdateCompletedEventHandler(Current_CheckAndDownloadUpdateCompleted);
            Loaded += new RoutedEventHandler(MainPage_Loaded);
        }

        void Current_CheckAndDownloadUpdateCompleted(object sender, CheckAndDownloadUpdateCompletedEventArgs e)
        {
            if (e.UpdateAvailable)
            {
                MessageBox.Show("An update has been installed.  To see the updates please exit and restart the application.");
            }
        }

        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            if (App.Current.InstallState == InstallState.Installed)
            {
                InstallContainer.Visibility = Visibility.Collapsed;
            }

            InstallBtn.Click += new RoutedEventHandler(InstallBtn_Click);
        }

            void InstallBtn_Click(object sender, RoutedEventArgs e)
            {
                App.Current.Install();
            }
    }
}
