﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;
using System.Windows.Media.Imaging;

namespace ImageDrop
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
            Drop += new DragEventHandler(MainPage_Drop);
        }

        void MainPage_Drop(object sender, DragEventArgs e)
        {
            FrameworkElement fe = sender as FrameworkElement;
            String objectName = fe.Name;
            IDataObject dataObject = e.Data as IDataObject;
            FileInfo[] files = dataObject.GetData(DataFormats.FileDrop) as FileInfo[];

            foreach (FileInfo file in files)
            {
                if (file.Extension == ".JPG")
                {

                    using (var stream = file.OpenRead())
                    {
                        var imageSource = new BitmapImage();
                        imageSource.SetSource(stream);
                        Image img = new Image();
                        img.Source = imageSource;
                        img.Height = 300;
                        LayoutRoot.Children.Add(img);
                    }
                }

            }
        }
    }
}
