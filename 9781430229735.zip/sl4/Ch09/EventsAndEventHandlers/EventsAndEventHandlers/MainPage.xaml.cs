﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace EventsAndEventHandlers
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
            MyButton.Click += new RoutedEventHandler(MyButton_Click);
        }

        void MyButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("I was clicked");
        }

        private void MyButton_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
        	// TODO: Add event handler implementation here.
			MessageBox.Show("MyButton was MouseEntered");
        }

        private void MyButton_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
        	// TODO: Add event handler implementation here.
			MessageBox.Show("MyButton was MouseLeave");
        }

        private void LayoutRoot_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
        	// TODO: Add event handler implementation here.
			MessageBox.Show("MouseLeftButtonDown event fired");
        }

        private void LayoutRoot_MouseLeftButtonUp(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
        	// TODO: Add event handler implementation here.
			MessageBox.Show("MouseLeftButtonUp event fired");
        }

        private void Image_MouseRightButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
			MyImage.Opacity = 1;
		}

        private void MyRect_MouseWheel(object sender, System.Windows.Input.MouseWheelEventArgs e)
        {
        	// TODO: Add event handler implementation here.
			double RectHeight = MyRect.Height;
			double RectWidth = MyRect.Width;
			int delta = e.Delta;
			MyRect.Height += delta /2;
			
        }

       

    } 	 
}
