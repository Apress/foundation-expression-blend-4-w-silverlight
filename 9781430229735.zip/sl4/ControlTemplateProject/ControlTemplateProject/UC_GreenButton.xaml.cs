﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace ControlTemplateProject
{
	public partial class UC_GreenButton : UserControl
	{


        #region GreenButtonsTextProperty DP

        public static readonly DependencyProperty GreenButtonsTextProperty =
       DependencyProperty.Register(
            "GreenButtonsText", typeof(String),
               typeof(UC_GreenButton), null);
        public String GreenButtonsText
        {
            get { return (String)GetValue(GreenButtonsTextProperty); }
            set { SetValue(GreenButtonsTextProperty, value); }
        }

        #endregion GreenButtonsTextProperty DP 


		public UC_GreenButton()
		{
			// Required to initialize variables
			InitializeComponent();
            Loaded += new RoutedEventHandler(UC_GreenButton_Loaded);
		}

        void UC_GreenButton_Loaded(object sender, RoutedEventArgs e)
        {
            MainText.Text = GreenButtonsText;
        }
	}
}