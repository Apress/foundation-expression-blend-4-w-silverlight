﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Xml.Serialization;
using System.Collections.Generic;

namespace SLVideoPlayer01
{
    [XmlRoot("VideoData")]
    public class VideoData : List<Video>
    {

        private Video _Video = null;
        public Video Video
        {
            get { return _Video; }
            set { _Video = value; }
        }
    }
}
