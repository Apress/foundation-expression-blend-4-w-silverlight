﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SLVideoPlayer01
{
    public partial class UC_VideoDragger : UserControl
    {
        #region VideoURL (DependencyProperty)


        public string VideoURL
        {
            get { return (string)GetValue(VideoURLProperty); }
            set { SetValue(VideoURLProperty, value); }
        }
        public static readonly DependencyProperty VideoURLProperty =
            DependencyProperty.Register("VideoURL", typeof(string),
 typeof(UC_VideoDragger),
              new PropertyMetadata(string.Empty));

        #endregion VideoURL

        #region Xprop (DependencyProperty)

        public double Xprop
        {
            get { return (double)GetValue(XpropProperty); }
            set { SetValue(XpropProperty, value); }
        }
        public static readonly DependencyProperty XpropProperty =
            DependencyProperty.Register("Xprop", typeof(double),
typeof(UC_VideoDragger),
            new PropertyMetadata(0.0));

        #endregion Xprop (DependencyProperty)

        #region YProp (DependencyProperty)

        public double YProp
        {
            get { return (double)GetValue(YPropProperty); }
            set { SetValue(YPropProperty, value); }
        }
        public static readonly DependencyProperty YPropProperty =
            DependencyProperty.Register("YProp", typeof(double),
typeof(UC_VideoDragger),
            new PropertyMetadata(0.0));

        #endregion YProp (DependencyProperty)

        public UC_VideoDragger()
        {
            InitializeComponent();
        }
    }
}
