﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Xml.Serialization;
using System.Xml;
using System.IO;
using System.Windows.Media.Imaging;
using System.Windows.Interactivity;
using Microsoft.Expression.Interactivity.Layout;


namespace SLVideoPlayer01
{
    public partial class MainPage : UserControl
    {

        private double Xprop = 10;
        private double Yprop = 10;


        public MainPage()
        {
            InitializeComponent();
            Loaded += new RoutedEventHandler(MainPage_Loaded);
        }

        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            WebClient xmlClient = new WebClient();
            xmlClient.DownloadStringCompleted += new DownloadStringCompletedEventHandler(xmlClient_DownloadStringCompleted);
            xmlClient.DownloadStringAsync(new Uri("videodata.xml", UriKind.RelativeOrAbsolute));

        }

        void xmlClient_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            // if e.error is null we can proceed.
            if (e.Error == null)
            {
                string xmlData = e.Result;
                // comment out the MessageBox as we know our XML is being parsed correctly
                //MessageBox.Show(xmlData);

                // Create the XmlSerializer
                XmlSerializer x = new XmlSerializer(typeof(VideoData));

                using (XmlReader reader = XmlReader.Create(new StringReader(xmlData)))
                {
                    // deserialize the XmlDate and set it to
                    // our DataFactory VideoData object

                    DataFactory.CLRInstance.VideoData = (VideoData)x.Deserialize(reader);
                    CreateVideoDraggerUserControls();
                }
            }

        }

        private void CreateVideoDraggerUserControls()
        {
            foreach (Video v in DataFactory.CLRInstance.VideoData)
            {
                // create a new instance of UC_VideoDragger
                //UC_VideoDragger videoDragger = new
                UC_VideoDragger videoDragger = new UC_VideoDragger();

                // set the PreviewImage source
                videoDragger.PreviewImage.Source = new BitmapImage(new Uri(v.ThumbnailImage, UriKind.RelativeOrAbsolute));

                // set the video URl
                videoDragger.VideoURL = v.Url;

                // set the PreviewTextBlock text
                videoDragger.PreviewTextBlock.Text = v.Title;

                // set the X and Y Prop to local values
                videoDragger.Xprop = Xprop;
                videoDragger.YProp = Yprop;

                // set the x and y location on the DragCanvas Canvas
                videoDragger.SetValue(Canvas.LeftProperty, Xprop);
                videoDragger.SetValue(Canvas.TopProperty, Yprop);

                // set the cursor to the Hand cursor
                videoDragger.Cursor = Cursors.Hand;

                // add videoDragger to the DragCanvas
                DragCanvas.Children.Add(videoDragger);

                // Add 150 units to XProp
                Xprop += 150;

                // Attach the MouseDragElementBehavior to videoDragger
                MouseDragElementBehavior dragBehavior = new MouseDragElementBehavior();
                dragBehavior.Attach(videoDragger);

                videoDragger.MouseLeftButtonUp += new MouseButtonEventHandler(videoDragger_MouseLeftButtonUp);
            }

        }

        void videoDragger_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            // get a list of all visual elements in the VisualTree            
            IEnumerable<UIElement> mylist = VisualTreeHelper.FindElementsInHostCoordinates(e.GetPosition(this), this);

            //cycle through each element
            foreach (UIElement uie in mylist)
            {
                // if this element is a MediaElement
                if (uie is MediaElement)
                {
                    // create a UC_VideoDragger element

                    UC_VideoDragger videoDragger = sender as UC_VideoDragger;

                    // make sure it is not null
                    if (videoDragger != null)
                    {
                        // pause the MediaElement (named ME)
                        ME.Pause();

                        // create the URI based upon the videoDragger
                        Uri srcUri = new Uri(videoDragger.VideoURL, UriKind.RelativeOrAbsolute);

                        // set the Source of ME
                        ME.Source = srcUri;

                        // play the ME
                        ME.Play();

                        // Create a GenderalTransform to find out where the videoDragger originated from
                        GeneralTransform gtf = videoDragger.TransformToVisual(videoDragger) as GeneralTransform;

                        // Send it back to its orginal postion
                        Point currentPoint = gtf.Transform(new Point(0, 0));
                        videoDragger.RenderTransform = new TranslateTransform();
                    }
                }
            }

        }
        //void videoDragger_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        //{


        //    // get a list of all visual elements in the visual tree
        //    IEnumerable<UIElement> treeList = VisualTreeHelper.FindElementsInHostCoordinates(e.GetPosition(this), this);

        //    // cycle through each element

        //    foreach (UIElement uie in treeList)
        //    {
        //        // if element is a MediaElement
        //        if (uie.GetType() ==  typeof(MediaElement))
        //        {
        //            // recreate the UC_VideoDragger element
        //            UC_VideoDragger videoDragger = sender as UC_VideoDragger;
        //            if (videoDragger != null)
        //            {
        //                // pause the MediaElement named ME
        //                ME.Pause();

        //                // create the URI based on the videoDragger
        //                Uri srcUri = new Uri(videoDragger.VideoURL, UriKind.RelativeOrAbsolute);

        //                // set the Source of ME
        //                ME.Source = srcUri;

        //                // Send videoDragger back to its original Postion
        //                videoDragger.SetValue(Canvas.LeftProperty, videoDragger.Xprop);
        //                videoDragger.SetValue(Canvas.TopProperty, videoDragger.YProp);

        //                // Tell ME to play
        //                ME.Play();
        //            }

        //        }
        //    }
        //}
    }
}
