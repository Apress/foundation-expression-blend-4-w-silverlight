﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SLVideoPlayer01
{
    public class DataFactory
    {
        #region Singleton

        protected static DataFactory _Singleton = new DataFactory();
        public static DataFactory CLRInstance
        {
            get
            {
                return _Singleton;
            }
        }
        public DataFactory Instance
        {
            get
            {
                return CLRInstance;
            }
        }

        #endregion Singleton

        private VideoData _VideoData = null;
        public VideoData VideoData
        {
            get { return _VideoData; }
            set { _VideoData = value; }
        }
    }
}
