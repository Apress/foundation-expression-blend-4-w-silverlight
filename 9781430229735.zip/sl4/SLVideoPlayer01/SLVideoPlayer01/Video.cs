﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SLVideoPlayer01
{
    public class Video
    {
        private string _Url = "";
        public string Url
        {
            get { return _Url; }
            set { _Url = value; }
        }

        private string _Title = "";
        public string Title
        {
            get { return _Title; }
            set { _Title = value; }
        }

        private string _ThumbnailImage = "";
        public string ThumbnailImage
        {
            get { return _ThumbnailImage; }
            set { _ThumbnailImage = value; }
        }
       
    }
}
