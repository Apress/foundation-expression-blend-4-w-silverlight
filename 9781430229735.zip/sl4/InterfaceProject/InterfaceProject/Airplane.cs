﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Diagnostics;

namespace InterfaceProject
{
    public class Airplane : Vehicle
    {

        public override void ShowModeOfTransporation()
        {
            Debug.WriteLine("An airplane’s mode of transportation is Wings");
        }

        public override void ShowNumberOfSeats()
        {
            base.ShowNumberOfSeats();
            Debug.WriteLine("A Plane has hundreds  of seats");
        }
    }
}
