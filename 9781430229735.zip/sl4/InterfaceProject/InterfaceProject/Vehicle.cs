﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Diagnostics;

namespace InterfaceProject
{

    public abstract class Vehicle : IModeOfTransporation, INumberOfSeats

    {

        #region IModeOfTransporation Members

        public abstract void ShowModeOfTransporation();

        #endregion

        #region INumberOfSeats Members

        public virtual void ShowNumberOfSeats()
        {
            Debug.WriteLine("Vehicle has no seats by default");
        }

        #endregion
    }
}
