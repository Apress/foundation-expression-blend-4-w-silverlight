﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;
using System.IO;
using Silverlight.Samples;

namespace PhotoboothApp
{
    public partial class MainPage : UserControl
    {
        CaptureSource CapSrc = new CaptureSource();
        VideoBrush MyVideoBrush = new VideoBrush();
        WriteableBitmap _bitmap;
        public MainPage()
        {
            InitializeComponent();
            Loaded += new RoutedEventHandler(MainPage_Loaded);
        }

        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            StartWebcamBtn.Click += new RoutedEventHandler(StartWebcamBtn_Click);
            TakeSnapshotBtn.Click += new RoutedEventHandler(TakeSnapshotBtn_Click);
            SaveImgBtn.Click += new RoutedEventHandler(SaveImgBtn_Click);
        }

        void SaveImgBtn_Click(object sender, RoutedEventArgs e)
        {
            SaveTheImg();
        }

        void TakeSnapshotBtn_Click(object sender, RoutedEventArgs e)
        {
            WriteableBitmap snapShot = new WriteableBitmap(WebcamRectangle, null);
            Image image = new Image();
            image.Width = 300;
            image.Source = snapShot;
            if (ImgHolder.Children.Count == 1)
            {
                ImgHolder.Children.RemoveAt(0);
            }
            ImgHolder.Children.Add(image);
        }

        void StartWebcamBtn_Click(object sender, RoutedEventArgs e)
        {
            if (CaptureDeviceConfiguration.AllowedDeviceAccess || CaptureDeviceConfiguration.RequestDeviceAccess())
            {
                MyVideoBrush.SetSource(CapSrc);
                WebcamRectangle.Fill = MyVideoBrush;
                CapSrc.Start();
            }
        }

        private void SaveTheImg()
        {
            _bitmap = new WriteableBitmap(ImgHolderParent, null);
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "PNG Files (*.png)|*.png|All Files (*.*)|*.*";
            sfd.DefaultExt = ".png";
            sfd.FilterIndex = 1;

            if ((bool)sfd.ShowDialog())
            {
                using (Stream fs = sfd.OpenFile())
                {
                    int width = _bitmap.PixelWidth;
                    int height = _bitmap.PixelHeight;

                    EditableImage ei = new EditableImage(width, height);

                    for (int i = 0; i < height; i++)
                    {
                        for (int j = 0; j < width; j++)
                        {
                            int pixel = _bitmap.Pixels[(i * width) + j];
                            ei.SetPixel(j, i,
                                        (byte)((pixel >> 16) & 0xFF),
                                        (byte)((pixel >> 8) & 0xFF),
                                        (byte)(pixel & 0xFF),
                                        (byte)((pixel >> 24) & 0xFF)
                            );
                        }
                    }
                    Stream png = ei.GetStream();
                    int len = (int)png.Length;
                    byte[] bytes = new byte[len];
                    png.Read(bytes, 0, len);
                    fs.Write(bytes, 0, len);
                }
            }
        }
    }
}
