﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Interactivity;

namespace SimpleBehavior
{
    public class FillBehavior : TargetedTriggerAction<FrameworkElement>
    {

        private Shape shape;
        private Brush originalColor;

        protected override void Invoke(object parameter)
        {
            shape = this.AssociatedObject as Shape;
            shape.MouseLeftButtonDown += new MouseButtonEventHandler(shape_MouseLeftButtonDown);
            shape.MouseLeftButtonUp += new MouseButtonEventHandler(shape_MouseLeftButtonUp);
            GetOriginalColor(shape);
        }

        private void GetOriginalColor(Shape shape)
        {
            originalColor = shape.Fill as Brush;
        }

        void shape_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            shape.Fill = originalColor;
        }

        void shape_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            shape.Fill = new SolidColorBrush(Colors.Red);
        }
    }
}
